# VyomGarud - Landing Page (Next.js + Tailwind)

This repository contains a production-ready starter for a dark, military-grade landing page called **VyomGarud**.
Built with Next.js (App Router) + Tailwind CSS.

## Features
- Hero, About, Capabilities, Highlights, Contact sections
- Responsive, dark aesthetic with orange accent (#ff7b00)
- Tailwind CSS setup
- Lightweight components (lucide-react icons)

## Quick start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Run development server:
   ```bash
   npm run dev
   ```
3. Open `http://localhost:3000`

## Deliverables
- GitHub-ready repository
- Screenshots in `/public/screenshots`

## Notes
- This is a starter — replace demo images in `/public/images` and adjust copy as needed.
