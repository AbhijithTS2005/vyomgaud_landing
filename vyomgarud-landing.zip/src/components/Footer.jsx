import React from 'react'
import { Mail } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="bg-gray-950 border-t border-gray-800 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-500 text-sm">
        <p className="font-extrabold tracking-widest mb-4" style={{ color: '#ff7b00' }}>VYOMGARUD</p>
        <div className="space-x-4 mb-4">
          <a href="mailto:info@vyomgarud.com" className="hover:text-white transition-colors"><Mail className="inline w-4 h-4 mr-1" /> info@vyomgarud.com</a>
          <span className="text-gray-700">|</span>
          <span>2025 &copy; VyomGarud Systems. All rights reserved.</span>
        </div>
        <p className="mt-2 text-xs">Engineering the impossible.</p>
      </div>
    </footer>
  )
}
