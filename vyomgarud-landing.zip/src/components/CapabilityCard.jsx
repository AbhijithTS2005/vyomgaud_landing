'use client'
import React from 'react'
import { Target } from 'lucide-react'

export default function CapabilityCard({ icon: Icon, title, description, features }) {
  return (
    <div className="group bg-gray-900 border border-gray-800 rounded-xl p-6 md:p-8 flex flex-col transition-all duration-300 hover:border-orange-500/50 hover:shadow-2xl hover:shadow-orange-900/30 cursor-pointer">
      <div className="flex items-center space-x-4 mb-4">
        <Icon className="w-8 h-8 transition-colors duration-300" style={{ color: '#ff7b00' }} />
        <h3 className="text-2xl font-semibold text-white group-hover:text-orange-300 transition-colors duration-300">{title}</h3>
      </div>
      <p className="text-gray-400 mb-6 flex-grow">{description}</p>
      <ul className="space-y-2 text-sm text-gray-400 border-t pt-4 border-gray-800">
        {features.map((f, i) => (
          <li key={i} className="flex items-center">
            <Target className="w-4 h-4 mr-2" style={{ color: '#ff7b00' }} />
            {f}
          </li>
        ))}
      </ul>
    </div>
  )
}
