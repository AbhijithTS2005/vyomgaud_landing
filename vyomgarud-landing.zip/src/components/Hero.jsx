'use client'
import React from 'react'

export default function Hero() {
  return (
    <section id="hero" className="relative h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ background: 'repeating-linear-gradient(45deg, #1f2937 0px, #1f2937 1px, transparent 1px, transparent 10px)' }}></div>
      <div className="absolute inset-0 bg-gray-950/30"></div>
      <div className="z-10 text-center max-w-4xl px-4">
        <p className="text-sm font-medium uppercase tracking-[0.3em] mb-4 accent">Advanced Unmanned Aerial Systems</p>
        <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight mb-6">Precision Autonomy. <br/> Unrivaled Reliability.</h1>
        <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">Engineering the future of aerial intelligence for mission-critical operations where failure is not an option.</p>
        <div className="flex justify-center space-x-4">
          <a href="#capabilities" className="px-8 py-3 text-lg font-semibold rounded-lg transition-all duration-300 border border-transparent text-gray-900 shadow-lg" style={{ backgroundColor: '#ff7b00' }}>Explore Systems</a>
          <a href="#contact" className="px-8 py-3 text-lg font-semibold rounded-lg transition-all duration-300 border-2 border-white text-white hover:bg-white hover:text-gray-950">Request Demo</a>
        </div>
      </div>
    </section>
  )
}
