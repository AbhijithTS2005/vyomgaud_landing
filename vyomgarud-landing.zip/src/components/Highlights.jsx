import React from 'react'
import { ShieldCheck, Target, Users } from 'lucide-react'

const highlights = [
  { icon: ShieldCheck, text: 'ITAR Compliant Engineering: Built to the highest international security and quality standards.' },
  { icon: Target, text: 'Sub-Meter GPS Accuracy: Unmatched precision for targeting, geolocation, and data acquisition.' },
  { icon: Users, text: 'Proprietary Redundancy Systems: Triple-layered fail-safes ensuring critical mission success.' },
]

export default function Highlights() {
  return (
    <section className="py-20 bg-gray-900 border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center mb-12">The VyomGarud Advantage</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {highlights.map((h, i) => {
            const Icon = h.icon
            return (
              <div key={i} className="flex flex-col items-center text-center p-6 border-2 border-gray-800 rounded-xl transition-all duration-300 hover:border-orange-500/50">
                <Icon className="w-10 h-10 mb-4" style={{ color: '#ff7b00' }} />
                <p className="text-lg text-gray-200">{h.text}</p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
