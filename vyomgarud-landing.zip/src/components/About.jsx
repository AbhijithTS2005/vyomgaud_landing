import React from 'react'

export default function About() {
  return (
    <section id="about" className="py-20 bg-gray-900 border-t border-b border-gray-800">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="md:col-span-1">
            <p className="text-xs font-medium uppercase tracking-widest mb-2 accent">OUR MISSION</p>
            <h3 className="text-4xl font-bold tracking-tight text-white leading-tight">Engineered for <span className="accent">Extremes.</span></h3>
          </div>
          <div className="md:col-span-2">
            <p className="text-xl text-gray-300 leading-relaxed">VyomGarud is dedicated to engineering the future of aerial intelligence. We develop autonomous UAV platforms that meet the most demanding requirements for surveillance, reconnaissance, and high-stakes operations, ensuring superior performance where failure is not an option.</p>
          </div>
        </div>
      </div>
    </section>
  )
}
