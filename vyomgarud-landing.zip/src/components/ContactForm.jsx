'use client'
import React, { useState } from 'react'
import { Mail } from 'lucide-react'

export default function ContactForm() {
  const [email, setEmail] = useState('')
  const [message, setMessage] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    alert('Demo request submitted — replace with real backend call.')
    setEmail(''); setMessage('')
  }

  return (
    <section id="contact" className="py-20 lg:py-32">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 bg-gray-900 p-8 md:p-12 rounded-xl border border-gray-800 shadow-2xl shadow-gray-950/50">
        <h2 className="text-4xl font-extrabold mb-4">Get in Touch</h2>
        <p className="text-gray-400 mb-8">Discuss your mission requirements or request a full technical brief. Our team is ready to assist.</p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">Work Email</label>
            <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="name@company.com" className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-colors" />
          </div>
          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">Mission Overview (Optional)</label>
            <textarea id="message" rows="4" value={message} onChange={(e) => setMessage(e.target.value)} className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:ring-1 focus:ring-orange-500 focus:border-orange-500 transition-colors" placeholder="I am interested in the Garud X1 for long-range ISR..."></textarea>
          </div>
          <button type="submit" className="w-full px-6 py-3 font-semibold text-lg rounded-lg transition-all duration-300 hover:opacity-90 shadow-lg" style={{ backgroundColor: '#ff7b00', color: 'rgb(10,10,10)' }}>Submit Demo Request</button>
        </form>
      </div>
    </section>
  )
}
