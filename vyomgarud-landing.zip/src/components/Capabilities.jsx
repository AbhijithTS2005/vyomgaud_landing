'use client'
import React from 'react'
import CapabilityCard from './CapabilityCard'
import { capabilities } from '../data/capabilities'

export default function Capabilities() {
  return (
    <section id="capabilities" className="py-20 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-sm font-medium uppercase tracking-widest text-center mb-2 accent">Our Systems</p>
        <h2 className="text-4xl md:text-5xl font-extrabold text-center mb-16">Unmanned Platforms</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {capabilities.map((c) => (
            <CapabilityCard key={c.id} {...c} />
          ))}
        </div>
      </div>
    </section>
  )
}
