import { TrendingUp, Zap, Cpu } from 'lucide-react'

export const capabilities = [
  {
    id: 'x1',
    icon: TrendingUp,
    title: 'Garud X1 (Reconnaissance)',
    description: 'Long-endurance ISR platform built for sustained, covert operations.',
    features: ['24h+ Flight Endurance', 'Multi-Spectral Sensor Payload', 'Silent Propulsion System'],
  },
  {
    id: 't4',
    icon: Zap,
    title: 'Garud T4 (Tactical)',
    description: 'Rapid-deployment V-TOL system for tactical superiority in urban & near-peer environments.',
    features: ['High-Speed Pursuit Mode', 'Quick-Change Payload Modules', 'Adaptive Urban Navigation'],
  },
  {
    id: 'ares',
    icon: Cpu,
    title: 'Garud ARES (AI Edge)',
    description: 'Autonomous edge AI platform enabling distributed networked operations.',
    features: ['Decentralized Swarm Control', 'Real-Time Edge Computing', 'Secure Mesh Networking'],
  },
]
