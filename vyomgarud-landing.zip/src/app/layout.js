import './globals.css'
export const metadata = {
  title: 'VyomGarud',
  description: 'Precision autonomy. Unrivaled reliability.',
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
