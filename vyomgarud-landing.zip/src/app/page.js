import Hero from '../../components/Hero'
import About from '../../components/About'
import Capabilities from '../../components/Capabilities'
import Highlights from '../../components/Highlights'
import ContactForm from '../../components/ContactForm'
import Footer from '../../components/Footer'

export default function Page() {
  return (
    <main className="min-h-screen bg-gray-950 font-sans text-white">
      <Hero />
      <About />
      <Capabilities />
      <Highlights />
      <ContactForm />
      <Footer />
    </main>
  )
}
